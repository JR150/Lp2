﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            mskbxAltura.Text = "";
            mskbxPeso.Text = "";

        }

        private void MskbxAltura_Validated(object sender, EventArgs e)
        {
            double Altura;
            errorProvider2.SetError(mskbxAltura, "");

            if (!double.TryParse(mskbxAltura.Text, out Altura) ||
                    (Altura <= 0))
            {
                MessageBox.Show("Altura Inválida");
                errorProvider2.SetError(mskbxAltura, "Altura inválida");
            }
        }

        private void MskbxPeso_Validated(object sender, EventArgs e)
        {
            double peso;
            errorProvider1.SetError(mskbxPeso, "");

            if (!double.TryParse(mskbxPeso.Text, out peso)||
                    (peso<=0))
            {
                MessageBox.Show("Peso Inválido");
                errorProvider1.SetError(mskbxPeso, "Peso inválido");

            }
        }

        private void BtnCalcular_Click(object sender, EventArgs e)
        {
            double pesoAtual=0, altura=0, imc=0;
            if (double.TryParse(mskbxAltura.Text, out altura) &&
                double.TryParse(mskbxPeso.Text, out pesoAtual))
            {
                if ((altura <= 0) || (pesoAtual <= 0))
                    MessageBox.Show("Valores devem ser maior que zero!");
                else
                {
                    imc = pesoAtual / (Math.Pow(altura, 2));
                    imc = Math.Round(imc, 1);
                    txtIMC.Text = imc.ToString();

                    if (imc < 18.5)
                        txtIMC.Text += "classificação: magreza";
                    else if (imc < 24.9)
                        txtIMC.Text += "classificação: normal";
                    else if (imc < 29.9)
                        txtIMC.Text += "classifiação: sobrepeso";
                    else if (imc < 39.9)
                        txtIMC.Text += "classifiação: obesidade";
                    else
                        txtIMC.Text += "classifiação: obesidade grave";
                }

            }
        }
    }
}
