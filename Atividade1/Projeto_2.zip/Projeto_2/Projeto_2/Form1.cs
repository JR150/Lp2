﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void CheckedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            listBox1.Items.Add("Sorocaba");
            listBox1.Items.Add("São Roque");
            listBox1.Items.Add("Mairinque");
            listBox1.SelectedIndex = 0;
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "") // (textBox1.text==string.Empty)
                MessageBox.Show("nome vazio!");
            else
                MessageBox.Show("o nome do aluno é:" + textBox1.Text);

            if (checkBox1.Checked)
                MessageBox.Show("o aluno é especial");
            else
                MessageBox.Show("o aluno NAO é especial");

            if (comboBox1.SelectedIndex == -1)
                MessageBox.Show("Turma não selecionada");
            else
                MessageBox.Show("Turma escolhida:" + comboBox1.SelectedItem);
            MessageBox.Show(listBox1.SelectedItem.ToString());

            if (radioButton1.Checked)
                MessageBox.Show("feminino");
            else
                MessageBox.Show("Masculino");

            //for (var i = 0; i<checkedListBox1.CheckedItems.Count; i++)
            //    MessageBox.Show(checkedListBox1.CheckedItems[i].ToString());
            string stringona = "";
            for (var i = 0; i < checkedListBox1.CheckedItems.Count; i++)
                stringona += checkedListBox1.CheckedItems[i].ToString()+ "\n";
            MessageBox.Show(stringona);
        }   
    }
}
