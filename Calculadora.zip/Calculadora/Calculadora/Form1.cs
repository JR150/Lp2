﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculadora
{
    public partial class Form1 : Form
    {
        double Num1, Num2, Resultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Label2_Click(object sender, EventArgs e)
        {

        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            txtNum1.Clear();
            txtNum2.Clear();
            txtResultado.Clear();


            txtNum1.Focus();
            Resultado = 0;
        }

        private void TxtNum2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNum2.Text, out Num2))
            {
                MessageBox.Show("Número Inválido!");
                txtNum2.Focus();
            }


        }

        private void BtnMais_Click(object sender, EventArgs e)
        {
            Resultado = Num1 + Num2;
            txtResultado.Text = Resultado.ToString();
        }

        private void BtnMenos_Click(object sender, EventArgs e)
        {
            Resultado = Num1 - Num2;
            txtResultado.Text = Resultado.ToString();
        }

        private void BtnMult_Click(object sender, EventArgs e)
        {
            Resultado = Num1 * Num2;
            txtResultado.Text = Resultado.ToString();
        }

        private void BtnDiv_Click(object sender, EventArgs e)
        {
            if (Num2 == 0)

            {
                MessageBox.Show("O denomiador não pode ser 0");
                txtNum2.Focus();
            }

            else

            {
                Resultado = Num1 / Num2;
                txtResultado.Text = Resultado.ToString();
            }
        }

        private void TxtResultado_TextChanged(object sender, EventArgs e)
        {

        }

        private void TxtNum1_TextChanged(object sender, EventArgs e)
        {

        }

        private void TxtNum1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNum1.Text, out Num1))
            {
                MessageBox.Show("Número Inválido!");
                txtNum1.Focus();
            }

        }
    }
}
